

<template>
 <!-- <Home /> -->
 <!-- <practice/> -->
 <router-link to="/home">Home</router-link>
 <router-link to="/about">About</router-link>

 <router-view></router-view>
</template>

<script >

// import Home from './components/home.vue'
// import Practice from './components/practice.vue'
export default{
    name:'App',
    // components:{
    //     Home,

    // //     // Practice,
    // }
    
}

</script> 
