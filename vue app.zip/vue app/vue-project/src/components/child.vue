<!-- <template>
    <h1>Child Component</h1>
    <h1>{{ data}}</h1>
     <h1>{{ data.email }}</h1>
    <h1>{{ data.address }}</h1>
   <h1>{{ data.name}}</h1>
    <h1>{{ data.age}}</h1> 



</template>
<script>
    export default{
        name:'child',
        props: {
           name:String,
           data:Object
        }
    }


</script> -->