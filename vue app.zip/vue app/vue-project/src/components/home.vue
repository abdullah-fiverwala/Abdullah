<!-- imterpolation and Data
<template>
  <h2>
    <h1>Email</h1>
    {{ email }}
  </h2>
  <h2>
    <h1>value</h1>
    {{ getvalue() }}
  </h2>
</template>
<script>
export default {
  value: "Home",

  data() {
    return {
      email: "Abdullahfiverwala@gmail.com",
      getvalue: function () {
        return "Syed Abdullah Shah";
      },
    };
  },
};
</script>
<style>
h1 {
  color: rgb(84, 84, 90);
}
h2 {
  font-size: 16px;
  color: brown;
}
</style> -->

<!-- Methods with Params -->

<!-- <template>
    <h1>{{getvalue()}}</h1>
    <h1>{{"Hassan"}}</h1>
    <h1>{{class}}</h1>

    <h1>All Data{{getData()}}</h1>


</template>
<script>
export default{
    data(){
        return{
            class:"12"
        }
    },
    methods:{
        getvalue(){
return"Abdullah";
        },
        getData(){
            return {
                value:"Safi Shah",
                Class:this.class
            }
        }
    }
}

</script> -->

<!-- Event with example, click event -->

<!-- <template> -->
<!-- <button v-on:click="fun()">Click</button><br> -->
<!-- // to pass data -->
<!-- <button v-on:click="getData('Please---------------')">Click</button><br> -->
<!-- for dubble click -->
<!-- <button v-on:dblclick="getData('Please---------------')">Click</button><br> -->
<!-- <h2>{{ count }}</h2> -->

<!-- 
</template>
<script>
export default{
value:'Home',
data(){
return{
    count:0
}
},
methods:{
    fun(){
        alert('Wnter Your Age')
        
    }, -->
<!-- // getData(){
    //     this.count=this.count+1;
    // },
//     to pass data
//  for buttons
    getData(data){
alert(data)
    }
}
}

</script> -->

<!-- TWO WAY BINDING -->

<!-- <template> -->
<!-- <input type="email" placeholder="Email" v-model="email" /><br />
  <br />
  <input type="passsword" placeholder="Password" v-model="password" />
  <button v-0n:click="getData()">Get Data</button> -->
<!-- <h2>Get CheckBox & Buttom Value</h2>
  <h3>Technologies</h3>
  <label for="html">Html</label>
  <input type="checkbox" value="html " id="html" v-model="technology">

  <label for="css">CSS</label>
  <input type="checkbox" value="css " id="css" v-model="technology">
  
  <label for="vue">Vue.JS</label>
  <input type="checkbox" value="vue" id="vue" v-model="technology">


  <h3>Who I Am</h3>
  <label for="student">Student</label>
  <input type="radio" name="who " value="student" id="student"  v-model="who">

  <label for="developer">Developer</label>
  <input type="radio" name="who " id="developer" value="developer" v-model="who">

  <h2>Selected Technology: {{ technology }}</h2>

  <h2>I am : {{ who }}</h2>

  
</template>
<script>
export default {
  value:"Home",
  data(){
    return{
    technology:[],
    who:null
    }
  }
    
  } -->
<!-- //   value: "Home",
//   data(){
// return{
//   email:null,
//   password:null
// }
//   },
//   methods: {
//     getData() {
//       console.warn("Value:",this.email,this.password);
//     },
//   },
// };
</script> -->

<!-- if else conditions | conditional rendering -->

<!-- <template>
<h1 v-if="show">if conditions.. </h1>
<h1 v-else-if="show">else conditions.. </h1>
<h1 v-else="show">Last conditions.. </h1>


<button v-on:click="show=!show">Toogle</button>

</template>\
<script>
   export default{
    name:"Home",
    data(){
      return{
        show:true
      }
    }




   }


</script> -->

<!-- For Loop and List -->

<!-- <template>
  <h1>List & Loops</h1>
  <ul>
    <li v-for="item in technology" :key="item">
    {{ item }}</li>
  </ul>
<br/>
  <ul>
    <li v-for="item in user" :key="item.age">
   Name: {{ item.name }}  and  Age: {{ item.age }}</li>
  </ul>
</template>
<script>
    export default{
      data(){
        return{
          technology:["Html","CSS","JavaScript"],
          user:[
            {name:"Syed", age:"21Year"},
            {name:"Abdullah", age:"21 Year"},
            {name:"Shah", age:"21 Year"}
          ]
        }

      }
    }

</script> -->

<!-- Pass Data Parent to Child Component -->

<!-- <template>
  <h1>Pass Data Parent to Child Component</h1> 
  <child :name="name" :data="user" />
</template>
<script>
 import child from './child.vue'
 export default{
name:"Home",
components:{
  child

},
data(){
  return{
    
    name:'Abdullah',
    user:{
      email:'XYZ@gmail.com',
      address:"califormia street D-302- North-America"
    }
  
  
  
  }

}

 }

</script> -->

<!-- Reuse Component
<template>
  <h1> Reuse Component</h1>
  <reuse :name="name"/>
</template>
<script>
import reuse from './reuse.vue'
export default{
  name:'Home',
  components:{
    reuse,
  },
data(){
  return{
    name:"Abdullah"
  }
}
}
</script> -->

<!-- HTML binding -->

<!-- <template>
  <div v-html="text1+text2+text3+text4+text5+text6"></div>
</template>
<script>
  export default{
    // name:'Home',

data(){
  return{
    text1:"<h1>Hello</h1>",
    text2:"<h2>Hello</h2>",
    text3:"<h3>Hello</h3>",
    text4:"<h4>Hello</h4>",
    text5:"<h5>Hello</h5>",
    text6:"<h6>Hello</h6>",
  }
}

  }
   

</script>   -->

<!-- Class binding -->

<!-- <template>
  <h1   :class="{text:colorful}">CLASS BINDING</h1>
  <button v-on:click="colorful=!colorful">Click Here</button>
</template>
<script>
export default{
  name:"Home",
  data(){
    return{
colorful:false
    }
  }
}
</script>
<style>
.text{
  font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}

</style> -->

<!-- Ref In Vue js -->

<!-- <template>
  <h1>Ref In Vue js</h1>
  <input type="text" ref="input">
  <button v-on:click="getData">Click Here</button>
</template>
<script>
 export default{
name:'Home',
methods:{
getData(){
this.$refs.input.focus()
}
}
 }

</script> -->

<!-- Simple form In VUe.js -->

<!-- <template>
  <h1>Login Form</h1>
  <form action="">
  <input type="text" placeholder="Name" v-model="form.name">
  <br>
  <br>
  <input type="password" placeholder="Password" v-model="form.password">
  <br>
  <br>

  <button v-on:click="login" type="button"  >
  Login
  </button>
</form>
</template>

<script>
  export default{
    name:'Home',
 
  data(){
       return{
        form:{
          name:'',
          password:''
        }
       }
    },
   
    methods:{
login(){
  console.log(this.form)
}
    }
  }

</script>
 -->

<!-- Router -->
<template>
  <h1>Home1</h1>
</template>
<script>
export default {
  name: "Home",
};
</script>
