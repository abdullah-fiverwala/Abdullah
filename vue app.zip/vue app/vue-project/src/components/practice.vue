<!-- <template>
    <button v-on:click="fun()">Subscribe1</button>
    <button v-on:click="getData1()">Increment</button>
    <button v-on:click="getData2()">Decrement</button>

    <h1>{{ count }}</h1>

</template>
<script>
export default{
    name:'Home',
  
  data(){
    return{
        count:110
    }
  },
    methods:{
       fun(){
        alert("Please enter your name to proceed")
       },

       getData1(){
        this.count=this.count+1
       },
       getData2(){
        this.count=this.count-1
       }
    //    getData(data){
    //     alert(data)
    //    }

     
    }
}
</script>
<style>

button{
    background-color: blueviolet;
    color: whitesmoke;
    padding: 15px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    text-transform: uppercase;
    font-weight: 600;
    font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    margin: 5px 5px;
}
button:hover{
background-color: rgb(152, 54, 244);
}

</style> -->
<!-- <template>
  <h1 :class="{font:change}">Class binding</h1>
  <button v-on:click="text=!text" :class="{color:text}">Class binding</button>

 <button v-on:click="change=!change">Please Click Here</button>
 
</template>
<script>

 export default{
  name:'practice',

   data(){
    return{
    change:false,
    text:false
    }
   }
 }
</script>
<style>
.font{
  font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}
.color{
  color: rgb(106, 105, 107);
  background-color: blueviolet;
}


</style> -->