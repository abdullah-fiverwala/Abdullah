<!-- <template>
<h1>{{ name }}</h1>

</template>
<script>
export default{
    name:'reuse',
    props:{
      name:String,  
    }
}

</script> -->
