import { createWebHistory, createRouter } from "vue-router";
import Home from "./components/home.vue";
import About from "./components/about.vue"

const routes = [
  {
    name: "routes",
    path: "/",
    component: Home,
  },
  {
    name: "Home",
    path: "/home",
    component: Home,
  },
  {
    name: "about",
    path: "/about",
    component: About,
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
