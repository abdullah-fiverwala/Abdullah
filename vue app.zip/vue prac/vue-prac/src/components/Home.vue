<template>
  <div class="hero-section">
    <div class="section-box">
      <h2>The<span>Progressive </span> <br />JavaScript Framework</h2>
      <h4>
        An approachable, performant and versatile framework for building web
        user interfaces.
      </h4>
      <div class="btn-box">
        <button>Why We ?</button>
        <button class="two-btn">Get Started</button>
        <button class="two-btn">Install</button>
      </div>
    </div>
  </div>
  <div class="brands">
    <div class="text">Special Sponsor</div>
    <div id="img"><img :src="appwrite" alt="appwrite" /></div>
    <div class="text">Build Fast. Scale Big. All in One Place</div>
  </div>

  <div class="card">
    <div>
      <h5>Approachable</h5>
      <p>
        Builds on top of standard<br> HTML, CSS and JavaScript <br>with intuitive API
        and world<br>-class documentation.
      </p>
    </div>
    <div>
      <h5>Performant</h5>
      <p>
        Truly reactive, compiler<br>-optimized rendering system <br>that rarely requires
        manual <br>optimization.
      </p>
    </div>
    <div>
      <h5>Versatile</h5>
      <p>
        A rich, incrementally <br>adoptable ecosystem that<br> scales between a library
        and<br> a full-featured framework
      </p>
    </div>
  </div>
</template>
<script>
import appwrite from "@/assets/appwrite.svg";
export default {
  name: "Home",
  data() {
    return {
      appwrite: appwrite,
    };
  },
};
</script>
<style>
.hero-section {
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
  margin: 90px auto 20px auto;
  /* font-family: 'Montserrat', sans-serif;
font-family: 'Roboto', sans-serif; */
}
.section-box {
  margin: 50px auto;
  justify-content: center;
  align-items: center;
  max-width: 960px;
}
.section-box h2 {
  font-size: 80px;
  font-weight: 900;
  line-height: 100px;
  color: #252240;
  letter-spacing: 1px;
}
.section-box h2 span {
  background: -webkit-linear-gradient(315deg, #42d392 25%, #647eff);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  padding-left: 20px;
}
.section-box h4 {
  font-size: 24px;
  font-weight: 300;
  color: rgb(107, 107, 107);
  padding: 25px 0;
}
.btn-box button {
  font-weight: 500;
  border-radius: 10px;
  margin-top: 10px;
}
.two-btn {
  background-color: #e3e3e3;
  color: #4c4c4f;
}
.brands {
  display: flex;
  justify-content: center;
  align-items: center;
  border-top: 1px solid rgb(221, 218, 218);
  border-bottom: 1px solid rgb(221, 218, 218);
  padding: 8px 0;
  margin-bottom: 30px;
}
.text {
  font-size: 14px;
  color: grey;
  padding: 0 30px;
}
#img {
  width: 168px;
  height: 40px;
  margin: 0 20px;
}
.card{
    display: flex;
    max-width: 960px;
    margin: 80px auto 80px auto;
    justify-content: space-around;
    align-items: center;

}

.card h5{
    font-size: 20px;
    color: rgb(54, 53, 53);
    padding-bottom: 15px;
}
.card p{
    font-size: 16px;
    line-height: 25px;
    color: grey;
}
</style>
