<template>
  <div class="nav">
    <h1 class="logo">Vue<span>App</span></h1>
    <ul>
      <li>Home</li>
      <li>About</li>
      <li>Service</li>
      <li>Projects</li>
      <li>Tasks</li>
    </ul> 
    <button>Login</button>
    <button id="signup">SignUp</button>
   
  </div>
</template>
<script>
export default {
  name: "Header",
};
</script>
<style>
* {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
  list-style: none;
  /* font-family: 'Montserrat', sans-serif; */
font-family: 'Roboto', sans-serif;
  cursor: pointer;
}
.nav {
  display: flex;
  justify-content: space-around;
  margin: auto;

  align-items: center;
  background-color:#1f1d32;
  padding: 10px 50px;
}
.logo span {
  color: rgb(73, 184, 114);
}
.logo {
  font-size: 30px;
  font-family: "Trebuchet MS", "Lucida Sans Unicode", "Lucida Grande",
    "Lucida Sans", Arial, sans-serif;
  font-weight: 700;
  color: aliceblue;
}
ul {
  display: flex;
  margin: auto;
}
ul li {
  padding: 0 25px;
  font-size: 18px;
  font-weight: 400;
  color: aliceblue;
}
ul li:hover{
    color: rgb(73, 184, 114) ;
}
button {
  background-color: rgb(73, 184, 114);
  color: white;
  padding: 10px 25px;
  font-size: 16px;
  border: none;
  border-radius: 5px;
  margin: 0 10px;
}
button:hover{
  background-color: rgb(55, 143, 87);
    transition: 0.3s ease;
    color: rgb(255, 255, 255);
}
#signup{
    background-color: white;
    color: rgb(68, 68, 68);
}
#signup:hover{
    transition: 0.3s ease;
    background-color: rgb(222, 222, 222);
    color:rgb(70, 70, 70) ;
}
</style>
